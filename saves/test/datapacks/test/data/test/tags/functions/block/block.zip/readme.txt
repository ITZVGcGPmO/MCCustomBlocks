create: block summoned into the world by player/dispenser/etc
destroy: block destroyed by player/piston/tnt/etc
drop: invalid block placement + player/dropper dropped item
open: opened block/gui
close: closed gui
tick: block tick

tags:
gui_opened: is gui open
gui_blocked: is gui blocked from opening
